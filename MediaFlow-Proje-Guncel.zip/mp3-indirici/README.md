# MP3 İndirici Pro — Yerel Masaüstü Uygulaması

Windows uygulaması, tarayıcı/WebView veya yerel web sunucusu kullanmadan açılan
masaüstü arayüzüdür. YouTube sesini MP3/Opus olarak indirebilir veya MP4 videoyu
ses ve görüntüyü birleştirerek kaydedebilir.

## Kullanım

1. `MP3-Indirici-Pro-Yerel-Masaustu-Windows.zip` dosyasını indirin.
2. ZIP'e sağ tıklayıp **Tümünü Çıkart** seçin.
3. Çıkan `MP3-Indirici-Pro` klasöründeki `MP3-Indirici-Pro.exe` dosyasını açın.
   `MP3-Indirici-Pro.exe` ile `_internal` klasörünü birlikte tutun.
4. YouTube bağlantısını yapıştırın; kısa bir süre sonra otomatik analiz edilir. İsterseniz **Analiz Et**'e de basabilirsiniz.
5. **Ses** veya **Video** seçin. En iyi kaynak sesi/en yüksek video varsayılan olarak ilk seçenektir; MP4 H.264 uyumlu seçenek de Video altında bulunur. Ardından indirmeyi başlatın.

Uygulama interneti YouTube'a erişmek için kullanır; bilgisayarınızda localhost
adresi açmaz ve tarayıcı başlatmaz.

## Özellikler

- Yerel masaüstü penceresi: HTTP sunucusu, tarayıcı veya localhost yok.
- Bağlantıyı analiz ettikten sonra ayrı **Ses** ve **Video** seçenekleri.
- Kaynağın en iyi ses akışı (yeniden kodlamadan), MP3 320/192 kbps ve Opus.
- En yüksek video çözünürlüğü/codec'i gösterilir; 4K/1440p/1080p gibi çözünürlükler seçilebilir ve tahmini dosya boyutu gösterilir.
- Windows uyumluluğu için ayrıca H.264 öncelikli MP4 seçeneği.
- İndirme yüzdesi, hız ve kalan süre; dönüştürme aşamasında hareketli gösterge.
- Görevler sırayla çalışır; bekleyen görevi kaldırabilir, çalışan görevi iptal edebilirsiniz.
- Kapak ve etiketlerin MP3'e eklenmesi.
- İndirilen dosyaları kütüphanede görme, açma, silme ve kayıt klasörünü açma.
- Dosyalar uygulamanın yanındaki `downloads` klasörüne yazılır.

## Kalite hakkında

YouTube'un ses kaynağı çoğunlukla zaten kayıplı biçimde sıkıştırılmıştır. MP3 320
kbps daha büyük bir MP3 dosyası üretir; kaynağın içermediği yeni ses ayrıntıları
eklemez. Opus genellikle daha küçük ve daha hızlıdır, ancak `.opus` dosyasıdır ve
teknik olarak kayıpsız değildir. **En iyi kaynak sesi** seçeneği YouTube'un sunduğu
en iyi ses akışını yeniden kodlamadan kaydeder. Video bölümünde uygulama bulunan
en yüksek çözünürlük ve codec'i gösterir; en yüksek kalite seçeneği videoyu kaynak
codec/container'ıyla kaydeder (MP4, WebM veya MKV olabilir). Ayrı MP4 seçeneği
Windows uyumluluğu için H.264 MP4 akışlarını önceliklendirir; bu seçenek en yüksek
çözünürlükten farklı olabilir. Çözünürlük seçeneklerindeki dosya boyutları süre ve
akış bitrate'ine göre yaklaşık hesaplanır; gerçek indirme boyutu değişebilir.

## Kendiniz derlemek (Windows)

`desktop_app.py` ve `EXE-YAP.bat` dosyalarını aynı klasöre koyun. Python 3.12+
kurulu olmalı ve `py` komutu çalışmalıdır. `EXE-YAP.bat` gerekli paketleri ve
Windows FFmpeg'i indirir, ardından şurada uygulamayı üretir:

```text
dist\MP3-Indirici-Pro\MP3-Indirici-Pro.exe
```

Bu bir klasör dağıtımıdır: EXE ve `_internal` klasörünü birlikte saklayın.

## Yasal uyarı

Uygulamayı yalnızca indirme hakkına sahip olduğunuz içerikler için kullanın.
