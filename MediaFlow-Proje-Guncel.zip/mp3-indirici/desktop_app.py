from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any

import yt_dlp
from PySide6.QtCore import Qt, QThread, Signal, QUrl, QTimer
from PySide6.QtGui import QDesktopServices, QFont, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QSplashScreen,
    QButtonGroup,
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

APP_NAME = "MediaFlow"
MEDIA_EXTS = {".mp3", ".mp4", ".opus", ".m4a", ".ogg", ".webm", ".mkv", ".wav", ".flac", ".aac"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}

if getattr(sys, "frozen", False):
    BASE = Path(sys.executable).resolve().parent
    RESOURCE = Path(getattr(sys, "_MEIPASS", BASE))
else:
    BASE = Path(__file__).resolve().parent
    RESOURCE = BASE


def find_ffmpeg() -> str | None:
    exe = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
    for candidate in (
        RESOURCE / "ffmpeg-bin" / exe,
        BASE / "ffmpeg-bin" / exe,
        Path(shutil.which("ffmpeg") or ""),
        Path.home() / "bin" / exe,
    ):
        try:
            if candidate.is_file():
                return str(candidate)
        except OSError:
            pass
    return shutil.which("ffmpeg")


FFMPEG = find_ffmpeg()
DOWNLOADS = BASE / "downloads"
DOWNLOADS.mkdir(parents=True, exist_ok=True)

FORMATS: dict[str, dict[str, Any]] = {
    "best-audio": {
        "label": "En iyi kaynak sesi · orijinal codec, dönüştürmesiz",
        "writethumbnail": False,
        "postprocessors": [],
        "format": "bestaudio/best",
    },
    "mp3-320": {
        "label": "MP3 320 kbps",
        "ext": "mp3",
        "writethumbnail": True,
        "postprocessors": [
            {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "320"},
            {"key": "FFmpegMetadata"},
            {"key": "EmbedThumbnail", "already_have_thumbnail": False},
        ],
    },
    "mp3-192": {
        "label": "MP3 192 kbps",
        "ext": "mp3",
        "writethumbnail": True,
        "postprocessors": [
            {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"},
            {"key": "FFmpegMetadata"},
            {"key": "EmbedThumbnail", "already_have_thumbnail": False},
        ],
    },
    "opus": {
        "label": "Opus (.opus) · çoğu kaynakta daha hızlı",
        "ext": "opus",
        "writethumbnail": False,
        "postprocessors": [
            {"key": "FFmpegExtractAudio", "preferredcodec": "opus"},
            {"key": "FFmpegMetadata"},
        ],
    },
    "max-video": {
        "label": "Video · en yüksek kaynak kalitesi",
        "writethumbnail": False,
        "postprocessors": [],
        "format": "bestvideo+bestaudio/best",
    },
    "mp4-video": {
        "label": "MP4 Video · Windows uyumlu H.264 öncelikli",
        "ext": "mp4",
        "writethumbnail": False,
        "postprocessors": [{"key": "FFmpegMetadata"}],
        "format": "bestvideo[ext=mp4][vcodec^=avc1]+bestaudio[ext=m4a]/best[ext=mp4][vcodec^=avc1]/best[ext=mp4]",
    },
}


def profile_for_format(format_id: str) -> dict[str, Any]:
    if str(format_id).startswith("video-height:"):
        max_height = max(1, int(str(format_id).split(":", 1)[1]))
        profile = dict(FORMATS["max-video"])
        profile["format"] = f"bestvideo[height<={max_height}]+bestaudio/best[height<={max_height}]"
        return profile
    return FORMATS[format_id]


def format_duration(value: Any) -> str:
    try:
        seconds = max(0, int(float(value)))
    except (TypeError, ValueError):
        return "Süre bilinmiyor"
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes}:{seconds:02d}"


def format_bytes(value: int | float | None) -> str:
    if not value:
        return "—"
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" or size >= 10 else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def _format_number(fmt: dict[str, Any], key: str) -> float:
    try:
        return float(fmt.get(key) or 0)
    except (TypeError, ValueError):
        return 0.0


def _has_codec(fmt: dict[str, Any], key: str) -> bool:
    return str(fmt.get(key) or "").lower() not in {"", "none"}


def _codec_label(codec: Any, video: bool = False) -> str:
    value = str(codec or "").lower()
    if not value or value == "none":
        return "bilinmiyor"
    if video:
        if value.startswith("avc1"):
            return "H.264"
        if value.startswith("av01"):
            return "AV1"
        if value.startswith("vp09"):
            return "VP9"
        if value.startswith("vp8"):
            return "VP8"
        if value.startswith(("hev1", "hvc1")):
            return "H.265/HEVC"
    else:
        if "opus" in value:
            return "Opus"
        if value.startswith("mp4a") or "aac" in value:
            return "AAC"
        if "vorbis" in value:
            return "Vorbis"
        if "flac" in value:
            return "FLAC"
        if "mp3" in value:
            return "MP3"
    return value.split(".", 1)[0].upper()


def _video_rank(fmt: dict[str, Any]) -> tuple[float, float, float, float, float]:
    return (
        _format_number(fmt, "height"),
        _format_number(fmt, "fps"),
        _format_number(fmt, "quality"),
        _format_number(fmt, "tbr"),
        _format_number(fmt, "source_preference"),
    )


def _video_quality_label(fmt: dict[str, Any]) -> str:
    height = int(_format_number(fmt, "height"))
    fps = _format_number(fmt, "fps")
    resolution = f"{height}p" if height else str(fmt.get("format_note") or fmt.get("resolution") or "çözünürlük bilgisi yok")
    if height >= 2160:
        resolution += " (4K)"
    elif height >= 1440:
        resolution += " (2K)"
    elif height >= 1080:
        resolution += " (Full HD)"
    elif height >= 720:
        resolution += " (HD)"
    if fps >= 20:
        resolution += f" {fps:g} fps"
    codec = _codec_label(fmt.get("vcodec"), video=True)
    ext = str(fmt.get("ext") or "").upper()
    parts = [resolution, codec]
    if ext:
        parts.append(ext)
    return " · ".join(parts)


def _audio_quality_label(fmt: dict[str, Any]) -> str:
    codec = _codec_label(fmt.get("acodec"))
    bitrate = _format_number(fmt, "abr") or _format_number(fmt, "tbr")
    sample_rate = _format_number(fmt, "asr")
    parts = [codec]
    if bitrate:
        parts.append(f"yaklaşık {bitrate:.0f} kb/sn")
    if sample_rate:
        parts.append(f"{sample_rate / 1000:g} kHz")
    ext = str(fmt.get("ext") or "").upper()
    if ext:
        parts.append(ext)
    return " · ".join(parts)


def _estimate_video_size_bytes(video_fmt: dict[str, Any] | None, audio_fmt: dict[str, Any] | None, duration: Any) -> float | None:
    if not video_fmt:
        return None
    try:
        seconds = float(duration or 0)
    except (TypeError, ValueError):
        return None
    if seconds <= 0:
        return None
    video_rate = _format_number(video_fmt, "tbr") or _format_number(video_fmt, "vbr")
    if video_rate <= 0:
        return None
    if _has_codec(video_fmt, "acodec"):
        total_rate = video_rate
        if not _format_number(video_fmt, "tbr"):
            total_rate += _format_number(video_fmt, "abr")
    else:
        audio_rate = (_format_number(audio_fmt, "abr") or _format_number(audio_fmt, "tbr")) if audio_fmt else 0
        if audio_rate <= 0:
            return None
        total_rate = video_rate + audio_rate
    return total_rate * 1000 / 8 * seconds


def _estimate_size_label(size_bytes: float | None) -> str:
    return f"tahm. {format_bytes(size_bytes)}" if size_bytes else "boyut tahmini yok"


def summarize_formats(formats: Any, duration: Any = None) -> dict[str, Any]:
    """Build user-facing quality hints and approximate sizes from extractor formats."""
    formats = [fmt for fmt in (formats or []) if isinstance(fmt, dict)]
    audio_formats = [fmt for fmt in formats if _has_codec(fmt, "acodec") and not _has_codec(fmt, "vcodec")]
    if not audio_formats:
        audio_formats = [fmt for fmt in formats if _has_codec(fmt, "acodec")]
    video_formats = [fmt for fmt in formats if _has_codec(fmt, "vcodec")]
    mp4_formats = [fmt for fmt in video_formats if str(fmt.get("ext") or "").lower() == "mp4"]
    h264_mp4_formats = [fmt for fmt in mp4_formats if str(fmt.get("vcodec") or "").lower().startswith("avc1")]

    audio_rank = lambda fmt: (
        _format_number(fmt, "abr") or _format_number(fmt, "tbr"),
        _format_number(fmt, "asr"),
        _format_number(fmt, "quality"),
        _format_number(fmt, "source_preference"),
    )
    best_audio = max(audio_formats, key=audio_rank, default=None)
    best_video = max(video_formats, key=_video_rank, default=None)
    best_mp4 = max(h264_mp4_formats or mp4_formats, key=_video_rank, default=None)
    mp4_audio_formats = [
        fmt for fmt in audio_formats
        if str(fmt.get("ext") or "").lower() == "m4a"
        or str(fmt.get("acodec") or "").lower().startswith("mp4a")
    ]
    best_mp4_audio = max(mp4_audio_formats, key=audio_rank, default=None) or best_audio

    video_resolutions = []
    heights = sorted({int(_format_number(fmt, "height")) for fmt in video_formats if _format_number(fmt, "height") > 0}, reverse=True)
    for height in heights:
        candidates = [fmt for fmt in video_formats if 0 < _format_number(fmt, "height") <= height]
        selected = max(candidates, key=_video_rank, default=None)
        size = _estimate_video_size_bytes(selected, best_audio, duration)
        if selected:
            video_resolutions.append({
                "height": height,
                "quality": _video_quality_label(selected),
                "estimate": _estimate_size_label(size),
                "size_bytes": size,
            })

    best_video_size = _estimate_video_size_bytes(best_video, best_audio, duration)
    best_mp4_size = _estimate_video_size_bytes(best_mp4, best_mp4_audio, duration)
    return {
        "best_audio_quality": _audio_quality_label(best_audio) if best_audio else "en iyi kaynak sesi otomatik seçilecek",
        "best_video_quality": _video_quality_label(best_video) if best_video else "en yüksek video kalitesi indirme sırasında seçilecek",
        "best_mp4_quality": _video_quality_label(best_mp4) if best_mp4 else "MP4 akış bilgisi yok",
        "best_video_estimate": _estimate_size_label(best_video_size),
        "best_mp4_estimate": _estimate_size_label(best_mp4_size),
        "video_resolutions": video_resolutions,
        "has_audio_formats": bool(audio_formats),
        "has_video_formats": bool(video_formats),
        "has_mp4_formats": bool(mp4_formats),
    }


def cleanup_partial(task_dir: Path) -> None:
    if not task_dir.exists():
        return
    for path in task_dir.rglob("*"):
        if path.is_file() and path.name.endswith((".part", ".ytdl", ".temp")):
            try:
                path.unlink()
            except OSError:
                pass


def friendly_error(message: str) -> str:
    text = (message or "").strip()
    low = text.lower()
    if "sign in to confirm your age" in low or ("age" in low and "restrict" in low):
        return "Bu video yaş kısıtlamalı ve giriş yapılmadan indirilemiyor."
    if "not a bot" in low:
        return "YouTube bağlantıyı geçici olarak engelledi. Birkaç dakika sonra tekrar deneyin."
    if "private video" in low:
        return "Bu video özel; yalnızca sahibi erişebilir."
    if "members-only" in low or "join this channel" in low:
        return "Bu video yalnızca kanal üyelerine açık."
    if "video unavailable" in low or "unavailable" in low:
        return "Video kullanılamıyor; silinmiş veya bölgenizde erişime kapalı olabilir."
    if "ffmpeg" in low:
        return "FFmpeg bulunamadı. Uygulama klasöründeki _internal klasörünü silmediğinizden emin olun."
    if "unsupported url" in low or "unable to extract" in low:
        return "Bağlantı çözümlenemedi. Geçerli bir YouTube bağlantısı yapıştırın."
    if "cancel" in low or "aborted" in low:
        return "İndirme iptal edildi."
    first = text.splitlines()[0] if text else "Bilinmeyen hata"
    return f"İşlem başarısız: {first[:260]}"


class AnalyzeWorker(QThread):
    succeeded = Signal(dict)
    failed = Signal(str)

    def __init__(self, url: str):
        super().__init__()
        self.url = url

    def run(self) -> None:
        try:
            opts: dict[str, Any] = {
                "quiet": True,
                "no_warnings": True,
                "skip_download": True,
                "socket_timeout": 30,
            }
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(self.url, download=False)
            if not info:
                raise RuntimeError("Bağlantıdan video bilgisi alınamadı.")
            is_playlist = info.get("_type") == "playlist" or bool(info.get("entries"))
            entries = info.get("entries") or []
            count = info.get("playlist_count") or info.get("n_entries")
            if not count and isinstance(entries, list):
                count = len([entry for entry in entries if entry])
            quality_formats = info.get("formats") or []
            if not quality_formats and isinstance(entries, list):
                first_with_formats = next(
                    (entry for entry in entries if isinstance(entry, dict) and entry.get("formats")),
                    None,
                )
                if first_with_formats:
                    quality_formats = first_with_formats.get("formats") or []
            self.succeeded.emit({
                "url": self.url,
                "title": info.get("title") or "Bilinmeyen başlık",
                "channel": info.get("channel") or info.get("uploader") or "",
                "duration": info.get("duration"),
                "is_playlist": is_playlist,
                "playlist_count": count,
                **summarize_formats(quality_formats, info.get("duration")),
            })
        except Exception as exc:
            self.failed.emit(friendly_error(str(exc)))


class DownloadWorker(QThread):
    progress = Signal(str, dict)
    succeeded = Signal(str, list)
    failed = Signal(str, str)
    cancelled = Signal(str)

    def __init__(self, task: dict[str, Any]):
        super().__init__()
        self.task = task
        self.cancel_event = threading.Event()

    def cancel(self) -> None:
        self.cancel_event.set()

    def emit_stage(self, stage: str, info: dict[str, Any] | None = None) -> None:
        payload = {"stage": stage}
        info = info or {}
        if info.get("title"):
            payload["title"] = info["title"]
        if info.get("playlist_index"):
            payload["playlist_index"] = info.get("playlist_index")
        if info.get("playlist_count"):
            payload["playlist_count"] = info.get("playlist_count")
        self.progress.emit(self.task["id"], payload)

    def run(self) -> None:
        task_id = self.task["id"]
        task_dir = DOWNLOADS / task_id
        task_dir.mkdir(parents=True, exist_ok=True)
        profile = profile_for_format(self.task["format"])

        def progress_hook(data: dict[str, Any]) -> None:
            if self.cancel_event.is_set():
                raise yt_dlp.utils.DownloadError("İşlem kullanıcı tarafından iptal edildi.")
            info = data.get("info_dict") or {}
            status = data.get("status")
            if status == "downloading":
                total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
                downloaded = data.get("downloaded_bytes") or 0
                percent = round(downloaded * 100 / total, 1) if total else None
                payload = {
                    "status": "downloading",
                    "stage": "İndiriliyor",
                    "progress": percent,
                    "speed": data.get("speed"),
                    "eta": data.get("eta"),
                    "title": info.get("title"),
                    "playlist_index": info.get("playlist_index"),
                    "playlist_count": info.get("playlist_count") or info.get("n_entries"),
                }
                self.progress.emit(task_id, payload)
            elif status == "finished":
                if self.task["format"] == "mp4-video":
                    stage = "MP4 video ve ses birleştiriliyor"
                elif self.task["format"] == "max-video" or str(self.task["format"]).startswith("video-height:"):
                    stage = "Video ve ses birleştiriliyor"
                elif self.task["format"] == "best-audio":
                    stage = "En iyi kaynak sesi kaydediliyor"
                else:
                    stage = "Ses dönüştürülüyor"
                self.progress.emit(task_id, {
                    "status": "converting",
                    "stage": stage,
                    "progress": None,
                    "speed": None,
                    "eta": None,
                    "title": info.get("title"),
                    "playlist_index": info.get("playlist_index"),
                    "playlist_count": info.get("playlist_count") or info.get("n_entries"),
                })

        def postprocessor_hook(data: dict[str, Any]) -> None:
            if data.get("status") != "started":
                return
            pp = data.get("postprocessor")
            if pp == "EmbedThumbnail":
                self.emit_stage("Kapak ve etiketler ekleniyor", data.get("info_dict"))
            elif pp == "Merger":
                stage = (
                    "MP4 video ve ses birleştiriliyor"
                    if self.task["format"] == "mp4-video"
                    else "Video ve ses birleştiriliyor"
                )
                self.emit_stage(stage, data.get("info_dict"))
            elif pp == "FFmpegMetadata":
                self.emit_stage("Medya bilgileri ekleniyor", data.get("info_dict"))

        try:
            if not FFMPEG and self.task["format"] != "best-audio":
                raise RuntimeError("FFmpeg bulunamadı; dönüştürme veya video/ses birleştirme yapılamıyor.")
            opts: dict[str, Any] = {
                "outtmpl": str(task_dir / "%(title)s.%(ext)s"),
                "format": profile.get("format", "bestaudio/best"),
                "quiet": True,
                "no_warnings": True,
                "noprogress": True,
                "retries": 10,
                "fragment_retries": 10,
                "file_access_retries": 5,
                "socket_timeout": 30,
                "ignoreerrors": "only_download",
                "concurrent_fragment_downloads": 4,
                "restrictfilenames": False,
                "windowsfilenames": True,
                "writethumbnail": profile["writethumbnail"],
                "postprocessors": list(profile["postprocessors"]),
                "progress_hooks": [progress_hook],
                "postprocessor_hooks": [postprocessor_hook],
            }
            if self.task["format"] == "mp4-video":
                opts["merge_output_format"] = "mp4"
            if FFMPEG:
                opts["ffmpeg_location"] = str(Path(FFMPEG).parent)
            opts["remote_components"] = {"ejs:github"}

            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([self.task["url"]])

            if self.cancel_event.is_set():
                cleanup_partial(task_dir)
                self.cancelled.emit(task_id)
                return

            items: list[dict[str, Any]] = []
            for path in sorted(task_dir.rglob("*")):
                if not path.is_file():
                    continue
                if path.suffix.lower() in IMAGE_EXTS:
                    try:
                        path.unlink()
                    except OSError:
                        pass
                elif path.suffix.lower() in MEDIA_EXTS:
                    items.append({"path": str(path), "name": path.name, "size": path.stat().st_size})
            if not items:
                raise RuntimeError("İndirilebilir bir medya dosyası bulunamadı.")
            self.succeeded.emit(task_id, items)
        except Exception as exc:
            # Yarım kalan geçici dosyaları temizle; tamamlanmış dosyaları koru.
            cleanup_partial(task_dir)
            if self.cancel_event.is_set():
                self.cancelled.emit(task_id)
            else:
                self.failed.emit(task_id, friendly_error(str(exc)))


class TaskCard(QFrame):
    cancel_requested = Signal(str)

    def __init__(self, task_id: str, title: str):
        super().__init__()
        self.task_id = task_id
        self.setObjectName("taskCard")
        row = QHBoxLayout(self)
        row.setContentsMargins(14, 12, 14, 12)
        row.setSpacing(12)

        body = QVBoxLayout()
        body.setSpacing(7)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("taskTitle")
        self.title_label.setWordWrap(True)
        self.status_label = QLabel("Sırada — önceki görev bitince başlayacak")
        self.status_label.setObjectName("taskStatus")
        self.status_label.setWordWrap(True)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(9)
        body.addWidget(self.title_label)
        body.addWidget(self.progress)
        body.addWidget(self.status_label)
        row.addLayout(body, 1)

        self.cancel_button = QPushButton("İptal")
        self.cancel_button.setObjectName("secondaryButton")
        self.cancel_button.setFixedWidth(68)
        self.cancel_button.clicked.connect(lambda: self.cancel_requested.emit(self.task_id))
        row.addWidget(self.cancel_button)
        self.set_state("queued", "Sırada — önceki görev bitince başlayacak", None)

    def set_state(self, status: str, stage: str, percent: float | None) -> None:
        self.status_label.setText(stage)
        if status == "converting":
            self.progress.setRange(0, 0)
            self.progress.setProperty("busy", True)
            self.progress.style().unpolish(self.progress)
            self.progress.style().polish(self.progress)
        elif status == "downloading" and percent is None:
            self.progress.setRange(0, 0)
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(max(0, min(100, int(percent or 0))))
        if status in {"done", "error", "cancelled"}:
            self.cancel_button.setEnabled(False)
            self.cancel_button.setText({"done": "Hazır", "error": "Hata", "cancelled": "İptal"}[status])
        else:
            self.cancel_button.setEnabled(True)
            self.cancel_button.setText("İptal")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(980, 820)
        self.setMinimumSize(700, 640)
        self.info_worker: AnalyzeWorker | None = None
        self.worker: DownloadWorker | None = None
        self.closing_after_worker = False
        self.current_info: dict[str, Any] | None = None
        self.tasks: dict[str, dict[str, Any]] = {}
        self.queue: list[str] = []
        self.cards: dict[str, TaskCard] = {}
        self.auto_analyze_timer = QTimer(self)
        self.auto_analyze_timer.setSingleShot(True)
        self.auto_analyze_timer.setInterval(900)
        self.auto_analyze_timer.timeout.connect(self.analyze)

        root = QWidget()
        root.setObjectName("root")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(28, 22, 28, 20)
        layout.setSpacing(14)

        header = QVBoxLayout()
        header.setSpacing(4)
        logo = QLabel("♫  MP3 İndirici Pro")
        logo.setObjectName("logo")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle = QLabel("Tamamen masaüstü uygulaması — tarayıcı açılmaz")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.addWidget(logo)
        header.addWidget(subtitle)
        layout.addLayout(header)

        input_frame = QFrame()
        input_frame.setObjectName("panel")
        input_layout = QVBoxLayout(input_frame)
        input_layout.setContentsMargins(16, 15, 16, 13)
        input_layout.setSpacing(10)
        url_row = QHBoxLayout()
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("YouTube bağlantısını buraya yapıştırın")
        self.url_input.textChanged.connect(self.schedule_auto_analyze)
        self.url_input.returnPressed.connect(self.analyze)
        self.analyze_button = QPushButton("Analiz Et")
        self.analyze_button.setObjectName("primaryButton")
        self.analyze_button.clicked.connect(self.analyze)
        url_row.addWidget(self.url_input, 1)
        url_row.addWidget(self.analyze_button)
        input_layout.addLayout(url_row)

        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("İndirme türü"))
        self.audio_radio = QRadioButton("Ses")
        self.video_radio = QRadioButton("Video")
        self.mode_group = QButtonGroup(self)
        self.mode_group.addButton(self.audio_radio)
        self.mode_group.addButton(self.video_radio)
        self.audio_radio.setChecked(True)
        self.audio_radio.setEnabled(False)
        self.video_radio.setEnabled(False)
        self.audio_radio.toggled.connect(lambda checked: checked and self.update_format_options("audio"))
        self.video_radio.toggled.connect(lambda checked: checked and self.update_format_options("video"))
        mode_row.addWidget(self.audio_radio)
        mode_row.addWidget(self.video_radio)
        mode_row.addStretch(1)
        input_layout.addLayout(mode_row)

        format_row = QHBoxLayout()
        self.format_combo = QComboBox()
        self.format_combo.setEnabled(False)
        self.download_button = QPushButton("İndirmeyi Başlat")
        self.download_button.setObjectName("primaryButton")
        self.download_button.setEnabled(False)
        self.download_button.clicked.connect(self.start_download)
        format_row.addWidget(QLabel("Kalite / biçim"))
        format_row.addWidget(self.format_combo, 1)
        format_row.addWidget(self.download_button)
        input_layout.addLayout(format_row)

        self.info_label = QLabel("Bağlantıyı yapıştırıp Analiz Et'e basın.")
        self.info_label.setObjectName("infoLabel")
        self.info_label.setWordWrap(True)
        input_layout.addWidget(self.info_label)
        self.quality_label = QLabel("En iyi ses ve video kalitesi analizden sonra gösterilir.")
        self.quality_label.setObjectName("qualityLabel")
        self.quality_label.setWordWrap(True)
        input_layout.addWidget(self.quality_label)
        layout.addWidget(input_frame)

        tasks_header = QHBoxLayout()
        tasks_title = QLabel("İNDİRME SIRASI")
        tasks_title.setObjectName("sectionTitle")
        self.queue_note = QLabel("Aynı anda tek görev çalışır")
        self.queue_note.setObjectName("mutedLabel")
        tasks_header.addWidget(tasks_title)
        tasks_header.addStretch(1)
        tasks_header.addWidget(self.queue_note)
        layout.addLayout(tasks_header)

        self.task_container = QWidget()
        self.task_layout = QVBoxLayout(self.task_container)
        self.task_layout.setContentsMargins(0, 0, 0, 0)
        self.task_layout.setSpacing(9)
        self.task_layout.addStretch(1)
        self.task_scroll = QScrollArea()
        self.task_scroll.setWidgetResizable(True)
        self.task_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.task_scroll.setWidget(self.task_container)
        self.task_scroll.setMinimumHeight(104)
        self.task_scroll.setMaximumHeight(230)
        layout.addWidget(self.task_scroll)

        library_header = QHBoxLayout()
        library_title = QLabel("KÜTÜPHANE")
        library_title.setObjectName("sectionTitle")
        library_header.addWidget(library_title)
        library_header.addStretch(1)
        self.open_folder_button = QPushButton("Klasörü Aç")
        self.open_folder_button.setObjectName("secondaryButton")
        self.open_folder_button.clicked.connect(self.open_download_folder)
        self.open_file_button = QPushButton("Dosyayı Aç")
        self.open_file_button.setObjectName("secondaryButton")
        self.open_file_button.clicked.connect(self.open_selected_file)
        self.delete_file_button = QPushButton("Sil")
        self.delete_file_button.setObjectName("secondaryButton")
        self.delete_file_button.clicked.connect(self.delete_selected_file)
        library_header.addWidget(self.open_folder_button)
        library_header.addWidget(self.open_file_button)
        library_header.addWidget(self.delete_file_button)
        layout.addLayout(library_header)

        self.library = QTableWidget(0, 3)
        self.library.setHorizontalHeaderLabels(["Dosya", "Tür", "Boyut"])
        self.library.setObjectName("library")
        self.library.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.library.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.library.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.library.verticalHeader().setVisible(False)
        self.library.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.library.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.library.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.library.doubleClicked.connect(self.open_selected_file)
        layout.addWidget(self.library, 1)

        location_row = QHBoxLayout()
        self.location_label = QLabel(f"Kayıt yeri: {DOWNLOADS}")
        self.location_label.setObjectName("mutedLabel")
        location_row.addWidget(self.location_label, 1)
        self.refresh_button = QPushButton("Yenile")
        self.refresh_button.setObjectName("secondaryButton")
        self.refresh_button.clicked.connect(self.refresh_library)
        location_row.addWidget(self.refresh_button)
        layout.addLayout(location_row)

        self.setCentralWidget(root)
        self.statusBar().showMessage("Hazır")
        self.setStyleSheet(self.stylesheet())
        self.refresh_library()

    @staticmethod
    def stylesheet() -> str:
        return """
        QWidget#root, QMainWindow { background:#0b0b14; color:#f2f2f7; font-family:'Segoe UI'; font-size:10pt; }
        QLabel { color:#e9e9f1; }
        QLabel#logo { color:#c45bdd; font-size:28pt; font-weight:800; padding:3px; }
        QLabel#subtitle, QLabel#mutedLabel { color:#9a9ab0; }
        QLabel#sectionTitle { color:#a9a9c1; font-size:10pt; font-weight:800; letter-spacing:1px; }
        QLabel#infoLabel { color:#b9b9cb; padding:5px 2px 0 2px; }
        QLabel#qualityLabel { color:#a9a9bd; font-size:9pt; padding:1px 2px 0 2px; }
        QRadioButton { color:#e9e9f1; spacing:8px; padding:4px 10px; }
        QFrame#panel, QFrame#taskCard { background:#171721; border:1px solid #30303d; border-radius:14px; }
        QLabel#taskTitle { color:#f2f2f7; font-weight:700; }
        QLabel#taskStatus { color:#fbbf24; font-size:9pt; }
        QLineEdit, QComboBox, QTableWidget { background:#101018; color:#f2f2f7; border:1px solid #333341; border-radius:9px; padding:9px 11px; selection-background-color:#8149c6; }
        QComboBox QAbstractItemView { background:#171721; color:#f2f2f7; selection-background-color:#8149c6; border:1px solid #333341; }
        QPushButton { color:#f8f8fc; border:0; border-radius:10px; padding:10px 14px; font-weight:700; }
        QPushButton#primaryButton { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #9055e9,stop:1 #e34ca6); }
        QPushButton#primaryButton:hover { background:#a95de5; }
        QPushButton#primaryButton:disabled { background:#4b4658; color:#a9a7b1; }
        QPushButton#secondaryButton { background:#272733; color:#d9d9e4; }
        QPushButton#secondaryButton:hover { background:#363643; }
        QProgressBar { background:#292936; border:0; border-radius:4px; min-height:8px; max-height:8px; }
        QProgressBar::chunk { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #9055e9,stop:1 #e34ca6); border-radius:4px; }
        QTableWidget { gridline-color:#292936; alternate-background-color:#14141d; }
        QHeaderView::section { background:#171721; color:#aaaabc; border:0; border-bottom:1px solid #333341; padding:8px; font-weight:700; }
        QTableWidget::item { padding:7px; }
        QScrollArea { background:transparent; }
        QStatusBar { color:#aaaabc; background:#0b0b14; }
        """

    def schedule_auto_analyze(self, text: str) -> None:
        self.auto_analyze_timer.stop()
        if re.match(r"^https?://\S+$", text.strip(), flags=re.I):
            self.auto_analyze_timer.start()

    def update_format_options(self, mode: str) -> None:
        if not self.current_info:
            return
        audio_quality = self.current_info.get("best_audio_quality") or "en iyi kaynak sesi otomatik seçilecek"
        video_quality = self.current_info.get("best_video_quality") or "en yüksek video kalitesi otomatik seçilecek"
        video_estimate = self.current_info.get("best_video_estimate") or "boyut tahmini yok"
        mp4_quality = self.current_info.get("best_mp4_quality") or "MP4 kalite bilgisi alınamadı"
        mp4_estimate = self.current_info.get("best_mp4_estimate") or "boyut tahmini yok"
        self.format_combo.blockSignals(True)
        self.format_combo.clear()
        if mode == "audio":
            self.format_combo.addItem(f"En iyi kaynak sesi — {audio_quality}", "best-audio")
            self.format_combo.addItem("MP3 320 kbps — yüksek kalite, daha büyük dosya", "mp3-320")
            self.format_combo.addItem("MP3 192 kbps — daha küçük dosya", "mp3-192")
            self.format_combo.addItem("Opus — küçük dosya, kaynak yeniden kodlanır", "opus")
        else:
            self.format_combo.addItem(
                f"En yüksek kalite — {video_quality} · {video_estimate}",
                "max-video",
            )
            resolutions = self.current_info.get("video_resolutions") or []
            highest_height = max((int(item.get("height") or 0) for item in resolutions), default=0)
            for item in resolutions:
                height = int(item.get("height") or 0)
                if height <= 0 or height >= highest_height:
                    continue
                quality_name = str(item.get("quality") or f"{height}p").split(" · ", 1)[0]
                self.format_combo.addItem(
                    f"{quality_name} · {item.get('estimate') or 'boyut tahmini yok'}",
                    f"video-height:{height}",
                )
            self.format_combo.addItem(
                f"MP4 H.264 öncelikli — {mp4_quality} · {mp4_estimate}",
                "mp4-video",
            )
        self.format_combo.setCurrentIndex(0)
        self.format_combo.blockSignals(False)
        self.format_combo.setEnabled(True)
        self.download_button.setEnabled(True)

    def analyze(self) -> None:
        self.auto_analyze_timer.stop()
        url = self.url_input.text().strip()
        if not re.match(r"^https?://", url, flags=re.I):
            self.show_error("Geçerli bir YouTube bağlantısı yapıştırın.")
            return
        if self.info_worker and self.info_worker.isRunning():
            return
        self.current_info = None
        self.audio_radio.setEnabled(False)
        self.video_radio.setEnabled(False)
        self.format_combo.setEnabled(False)
        self.download_button.setEnabled(False)
        self.analyze_button.setEnabled(False)
        self.analyze_button.setText("Analiz ediliyor…")
        self.info_label.setText("Video bilgileri alınıyor…")
        self.quality_label.setText("Ses ve video akışlarının kalitesi inceleniyor…")
        worker = AnalyzeWorker(url)
        self.info_worker = worker
        worker.succeeded.connect(self.on_info_ready)
        worker.failed.connect(self.on_info_error)
        worker.finished.connect(self.on_info_thread_finished)
        worker.start()

    def on_info_ready(self, info: dict[str, Any]) -> None:
        self.current_info = info
        title = info.get("title", "Bilinmeyen başlık")
        channel = info.get("channel") or ""
        if info.get("is_playlist"):
            count = info.get("playlist_count")
            suffix = f" · {count} video" if count else ""
            kind = f"Çalma listesi{suffix}"
        else:
            kind = format_duration(info.get("duration"))
        self.info_label.setText(f"{title}\n{channel}  ·  {kind}")
        audio_quality = info.get("best_audio_quality") or "en iyi kaynak sesi otomatik seçilecek"
        video_quality = info.get("best_video_quality") or "en yüksek video kalitesi indirme sırasında seçilecek"
        video_estimate = info.get("best_video_estimate") or "boyut tahmini yok"
        self.quality_label.setText(
            f"En iyi ses: {audio_quality}\nEn yüksek video: {video_quality} · {video_estimate}\nDosya boyutu tahminidir; gerçek sonuç değişebilir."
        )
        self.audio_radio.setEnabled(True)
        self.video_radio.setEnabled(True)
        self.audio_radio.setChecked(True)
        self.update_format_options("audio")
        self.statusBar().showMessage("Ses veya video seçin; her türde en yüksek kalite ilk sırada.", 7000)

    def on_info_error(self, message: str) -> None:
        self.current_info = None
        self.audio_radio.setEnabled(False)
        self.video_radio.setEnabled(False)
        self.format_combo.setEnabled(False)
        self.download_button.setEnabled(False)
        self.info_label.setText("Bağlantı analiz edilemedi.")
        self.quality_label.setText("Ses/video kalite bilgisi alınamadı.")
        self.show_error(message)

    def on_info_thread_finished(self) -> None:
        self.analyze_button.setEnabled(True)
        self.analyze_button.setText("Analiz Et")
        self.info_worker = None
        if self.closing_after_worker:
            self.close()

    def start_download(self) -> None:
        if not self.current_info:
            return
        url = self.current_info["url"]
        fmt_id = self.format_combo.currentData()
        task_id = uuid.uuid4().hex[:12]
        title = self.current_info.get("title") or "YouTube medyası"
        task = {
            "id": task_id,
            "url": url,
            "format": fmt_id,
            "title": title,
            "status": "queued",
            "progress": 0.0,
        }
        self.tasks[task_id] = task
        card = TaskCard(task_id, title)
        card.cancel_requested.connect(self.cancel_task)
        self.cards[task_id] = card
        self.task_layout.insertWidget(max(0, self.task_layout.count() - 1), card)
        self.queue.append(task_id)
        self.url_input.clear()
        self.current_info = None
        self.audio_radio.setEnabled(False)
        self.video_radio.setEnabled(False)
        self.format_combo.setEnabled(False)
        self.download_button.setEnabled(False)
        self.statusBar().showMessage("İndirme sıraya alındı.", 4000)
        self.start_next_task()

    def start_next_task(self) -> None:
        if self.worker is not None or not self.queue or self.closing_after_worker:
            return
        task_id = self.queue.pop(0)
        task = self.tasks[task_id]
        task["status"] = "downloading"
        card = self.cards.get(task_id)
        if card:
            card.set_state("downloading", "Bağlantı hazırlanıyor…", 0)
        worker = DownloadWorker(task)
        self.worker = worker
        worker.progress.connect(self.on_download_progress)
        worker.succeeded.connect(self.on_download_succeeded)
        worker.failed.connect(self.on_download_failed)
        worker.cancelled.connect(self.on_download_cancelled)
        worker.finished.connect(self.on_worker_finished)
        worker.start()

    def on_download_progress(self, task_id: str, data: dict[str, Any]) -> None:
        task = self.tasks.get(task_id)
        if not task:
            return
        if data.get("title"):
            task["title"] = data["title"]
        if data.get("status"):
            task["status"] = data["status"]
        percent = data.get("progress")
        if percent is not None:
            task["progress"] = percent
        stage = data.get("stage") or "İşleniyor"
        if data.get("speed"):
            stage += f"  ·  {format_bytes(data['speed'])}/sn"
        if data.get("eta") is not None:
            stage += f"  ·  yaklaşık {format_duration(data['eta'])} kaldı"
        if data.get("playlist_index") and data.get("playlist_count"):
            stage += f"  ·  video {data['playlist_index']}/{data['playlist_count']}"
        card = self.cards.get(task_id)
        if card:
            card.title_label.setText(task["title"])
            card.set_state(task.get("status", "downloading"), stage, percent)

    def on_download_succeeded(self, task_id: str, items: list) -> None:
        task = self.tasks.get(task_id)
        if task:
            task["status"] = "done"
        card = self.cards.get(task_id)
        if card:
            total = len(items)
            card.set_state("done", f"Hazır · {total} dosya", 100)
        self.refresh_library()
        self.statusBar().showMessage("İndirme tamamlandı.", 7000)

    def on_download_failed(self, task_id: str, message: str) -> None:
        task = self.tasks.get(task_id)
        if task:
            task["status"] = "error"
        card = self.cards.get(task_id)
        if card:
            card.set_state("error", message, 0)
        self.statusBar().showMessage("İndirme başarısız oldu.", 6000)

    def on_download_cancelled(self, task_id: str) -> None:
        task = self.tasks.get(task_id)
        if task:
            task["status"] = "cancelled"
        card = self.cards.get(task_id)
        if card:
            card.set_state("cancelled", "İptal edildi", 0)
        self.statusBar().showMessage("İndirme iptal edildi.", 5000)

    def on_worker_finished(self) -> None:
        worker = self.worker
        self.worker = None
        if worker:
            worker.deleteLater()
        if self.closing_after_worker:
            self.close()
        else:
            self.start_next_task()

    def cancel_task(self, task_id: str) -> None:
        if self.worker and self.worker.task["id"] == task_id:
            self.worker.cancel()
            card = self.cards.get(task_id)
            if card:
                card.status_label.setText("İptal isteniyor…")
                card.cancel_button.setEnabled(False)
            return
        if task_id in self.queue:
            self.queue.remove(task_id)
            task = self.tasks.get(task_id)
            if task:
                task["status"] = "cancelled"
            card = self.cards.get(task_id)
            if card:
                card.set_state("cancelled", "Sıradan kaldırıldı", 0)

    def refresh_library(self) -> None:
        DOWNLOADS.mkdir(parents=True, exist_ok=True)
        files = [path for path in DOWNLOADS.rglob("*") if path.is_file() and path.suffix.lower() in MEDIA_EXTS]
        files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        self.library.setRowCount(0)
        for path in files:
            row = self.library.rowCount()
            self.library.insertRow(row)
            name_item = QTableWidgetItem(path.stem)
            name_item.setData(Qt.ItemDataRole.UserRole, str(path))
            self.library.setItem(row, 0, name_item)
            self.library.setItem(row, 1, QTableWidgetItem(path.suffix.lstrip(".").upper()))
            self.library.setItem(row, 2, QTableWidgetItem(format_bytes(path.stat().st_size)))
        if not files:
            self.statusBar().showMessage("Kütüphane boş — indirdiğiniz sesler burada görünür.", 5000)

    def selected_file(self) -> Path | None:
        row = self.library.currentRow()
        if row < 0:
            return None
        item = self.library.item(row, 0)
        if not item:
            return None
        value = item.data(Qt.ItemDataRole.UserRole)
        return Path(value) if value else None

    def open_selected_file(self, *_args: Any) -> None:
        path = self.selected_file()
        if path and path.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def open_download_folder(self) -> None:
        DOWNLOADS.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(DOWNLOADS)))

    def delete_selected_file(self) -> None:
        path = self.selected_file()
        if not path or not path.exists():
            self.show_error("Önce kütüphaneden bir dosya seçin.")
            return
        answer = QMessageBox.question(
            self,
            "Dosyayı sil",
            f"Bu dosya kalıcı olarak silinsin mi?\n\n{path.name}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer == QMessageBox.StandardButton.Yes:
            try:
                path.unlink()
                self.refresh_library()
                self.statusBar().showMessage("Dosya silindi.", 4000)
            except OSError as exc:
                self.show_error(f"Dosya silinemedi: {exc}")

    def show_error(self, message: str) -> None:
        QMessageBox.warning(self, APP_NAME, message)

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt event API
        if self.worker and self.worker.isRunning():
            answer = QMessageBox.question(
                self,
                "İşlem devam ediyor",
                "İndirme/dönüştürme sürüyor. İptal isteği gönderip işlem sonlanınca kapatılsın mı?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer == QMessageBox.StandardButton.Yes:
                self.closing_after_worker = True
                self.queue.clear()
                self.worker.cancel()
                self.statusBar().showMessage("Kapatılıyor — geçerli işlem durduruluyor…")
            event.ignore()
            return
        if self.info_worker and self.info_worker.isRunning():
            self.closing_after_worker = True
            event.ignore()
            return
        event.accept()


def self_test() -> int:
    """Packaged-build smoke test: check the bundled FFmpeg executable."""
    if not FFMPEG or not Path(FFMPEG).is_file():
        return 20
    try:
        result = subprocess.run(
            [FFMPEG, "-version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=15,
            check=False,
        )
        return 0 if result.returncode == 0 else 21
    except Exception:
        return 22


def main() -> int:
    # Qt uses a GUI subsystem; no local HTTP server or browser is started.
    if "--self-test" in sys.argv:
        return self_test()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("MediaFlow")
    app.setWindowIcon(QIcon(str(RESOURCE / "assets" / "MediaFlow.ico")))
    app.setStyle("Fusion")

    splash_path = RESOURCE / "assets" / "MediaFlow-Splash.png"
    splash = None
    if splash_path.is_file():
        splash = QSplashScreen(QPixmap(str(splash_path)))
        splash.show()
        app.processEvents()

    window = MainWindow()
    window.setWindowIcon(QIcon(str(RESOURCE / "assets" / "MediaFlow.ico")))
    window.show()
    if splash is not None:
        splash.finish(window)
    if "--smoke-gui" in sys.argv:
        QTimer.singleShot(1500, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
