@echo off
chcp 65001 >nul
setlocal
title MediaFlow - Yerel Masaustu EXE Derleyici
cd /d "%~dp0"

echo ============================================================
echo    MEDIAFLOW - YEREL MASAUSTU UYGULAMASI
echo    Tarayici veya localhost kullanmaz.
echo ============================================================
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo [HATA] Python launcher bulunamadi. Python 3.12+ kurun.
  pause
  exit /b 1
)
if not exist "desktop_app.py" (
  echo [HATA] desktop_app.py bu klasorde bulunamadi.
  pause
  exit /b 1
)

echo [1/3] Python paketleri kuruluyor...
py -m pip install --disable-pip-version-check --no-warn-script-location pyinstaller yt-dlp PySide6-Essentials==6.9.3
if errorlevel 1 (
  echo [HATA] Python paketleri kurulamadi. Internet baglantinizi kontrol edin.
  pause
  exit /b 1
)

if exist "ffmpeg-bin\ffmpeg.exe" (
  echo [2/3] ffmpeg zaten mevcut.
) else (
  echo [2/3] Windows ffmpeg indiriliyor (yaklasik 100 MB)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $u='https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'; $z=Join-Path $env:TEMP 'ffmpeg-ess.zip'; Invoke-WebRequest $u -OutFile $z; Add-Type -AssemblyName System.IO.Compression.FileSystem; $x=[IO.Compression.ZipFile]::OpenRead($z); New-Item -ItemType Directory -Force -Path 'ffmpeg-bin' | Out-Null; $e=$x.Entries | Where-Object { $_.FullName -match 'bin/ffmpeg\.exe$' } | Select-Object -First 1; if($e){ [IO.Compression.ZipFileExtensions]::ExtractToFile($e,(Join-Path 'ffmpeg-bin' 'ffmpeg.exe'),$true) }; $x.Dispose(); Remove-Item $z"
)
if not exist "ffmpeg-bin\ffmpeg.exe" (
  echo [HATA] ffmpeg indirilemedi. Internet baglantisini kontrol edin.
  pause
  exit /b 1
)

echo [3/3] Yerel masaustu EXE derleniyor...
py -m PyInstaller --noconfirm --clean --onedir --windowed ^
  --name "MediaFlow" ^
  --icon "assets\MediaFlow.ico" ^
  --add-data "assets;assets" ^
  --collect-all yt_dlp ^
  --add-binary "ffmpeg-bin\ffmpeg.exe;ffmpeg-bin" ^
  desktop_app.py
if errorlevel 1 (
  echo [HATA] Derleme basarisiz oldu.
  pause
  exit /b 1
)

echo.
echo EXE HAZIR: dist\MediaFlow\MediaFlow.exe
echo Uygulamayi Python, tarayici veya localhost olmadan calistirabilirsiniz.
echo EXE ile _internal klasorunu birlikte saklayin.
echo.
start "" "dist\MediaFlow\MediaFlow.exe"
endlocal
